import time
from django.http import JsonResponse
from django.core.cache import cache
from django.conf import settings
from django.shortcuts import render
import redis as redis_lib
import os

def _redis_client():
    host = os.getenv("REDIS_HOST", "redis")
    port = int(os.getenv("REDIS_PORT", "6379"))
    return redis_lib.Redis(host=host, port=port, db=0, decode_responses=True)

def welcome(request):
    """
    Welcome page that shows app information and available endpoints
    """
    context = {
        'app_name': 'Django Redis Demo',
        'description': 'A demonstration of Django with Redis integration using Docker',
        'endpoints': [
            {'path': '/ping/', 'description': 'Check Redis connection status'},
            {'path': '/cached-now/', 'description': 'Demonstrate caching with timestamps'},
            {'path': '/hits/', 'description': 'Redis-based hit counter'},
        ]
    }
    return render(request, 'app/welcome.html', context)

def ping(request):
    # Raw Redis ping (liveness)
    r = _redis_client()
    pong = r.ping()
    return JsonResponse({"service": "web", "redis": "PONG" if pong else "NOPE"})

def cached_now(request):
    """
    Demonstrates caching: the timestamp is computed once and cached for TTL.
    Refresh the browser within TTL and it returns the cached value.
    """
    key = "demo:cached_now"
    value = cache.get(key)
    if value is None:
        value = {"generated_at_epoch": time.time()}
        cache.set(key, value, timeout=settings.CACHE_TTL)
        cached = False
    else:
        cached = True
    return JsonResponse({"cached": cached, "value": value, "ttl": settings.CACHE_TTL})

def hit_counter(request):
    """
    Simple atomic counter using Redis INCR to show session-safe increments.
    """
    r = _redis_client()
    count = r.incr("demo:hits")
    return JsonResponse({"hits": count})
