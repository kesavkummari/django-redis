from django.urls import path
from .views import ping, cached_now, hit_counter

urlpatterns = [
    path("", ping, name="index"),  # Root path points to ping view
    path("ping/", ping, name="ping"),
    path("cached-now/", cached_now, name="cached_now"),
    path("hits/", hit_counter, name="hit_counter"),
]
